package com.potterthecoder.spring_preparation.a0001_whatisdi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A0001WhatIsDiApplicationTests {

	@Test
	void contextLoads() {
	}

}
