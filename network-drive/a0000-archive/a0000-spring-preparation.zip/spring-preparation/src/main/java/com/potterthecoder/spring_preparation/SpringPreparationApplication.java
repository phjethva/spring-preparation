package com.potterthecoder.spring_preparation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPreparationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPreparationApplication.class, args);
	}

}
