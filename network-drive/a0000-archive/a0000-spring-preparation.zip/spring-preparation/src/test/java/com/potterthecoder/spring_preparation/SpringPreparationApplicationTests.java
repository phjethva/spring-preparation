package com.potterthecoder.spring_preparation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPreparationApplicationTests {

	@Test
	void contextLoads() {
	}

}
